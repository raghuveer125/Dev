import numpy as np  # noqa
import pandas as pd  # noqa
from pandas import DataFrame

from freqtrade.strategy import IStrategy

import talib.abstract as ta 
import freqtrade.vendor.qtpylib.indicators as qtpylib
from technical.util import resample_to_interval, resampled_merge

def supertrend(dataframe, multiplier=3, period=10):
    df = dataframe.copy()

    df['TR'] = ta.TRANGE(df)
    df['ATR'] = df['TR'].ewm(alpha=1 / period).mean()

    st = 'ST_' + str(period) + '_' + str(multiplier)
    stx = 'STX_' + str(period) + '_' + str(multiplier)

    df['basic_ub'] = (df['high'] + df['low']) / 2 + multiplier * df['ATR']
    df['basic_lb'] = (df['high'] + df['low']) / 2 - multiplier * df['ATR']

    df['final_ub'] = 0.00
    df['final_lb'] = 0.00
    for i in range(period, len(df)):
        df['final_ub'].iat[i] = df['basic_ub'].iat[i] if df['basic_ub'].iat[i] < df['final_ub'].iat[i - 1] or df['close'].iat[i - 1] > df['final_ub'].iat[i - 1] else df['final_ub'].iat[i - 1]
        df['final_lb'].iat[i] = df['basic_lb'].iat[i] if df['basic_lb'].iat[i] > df['final_lb'].iat[i - 1] or df['close'].iat[i - 1] < df['final_lb'].iat[i - 1] else df['final_lb'].iat[i - 1]

    df[st] = 0.00
    for i in range(period, len(df)):
        df[st].iat[i] = df['final_ub'].iat[i] if df[st].iat[i - 1] == df['final_ub'].iat[i - 1] and df['close'].iat[i] <= df['final_ub'].iat[i] else \
                        df['final_lb'].iat[i] if df[st].iat[i - 1] == df['final_ub'].iat[i - 1] and df['close'].iat[i] >  df['final_ub'].iat[i] else \
                        df['final_lb'].iat[i] if df[st].iat[i - 1] == df['final_lb'].iat[i - 1] and df['close'].iat[i] >= df['final_lb'].iat[i] else \
                        df['final_ub'].iat[i] if df[st].iat[i - 1] == df['final_lb'].iat[i - 1] and df['close'].iat[i] <  df['final_lb'].iat[i] else 0.00 

    df[stx] = np.where((df[st] > 0.00), np.where((df['close'] < df[st]), 'down',  'up'), np.NaN)

    df.drop(['basic_ub', 'basic_lb', 'final_ub', 'final_lb'], inplace=True, axis=1)

    df.fillna(0, inplace=True)

    return df

class BD_1m_Supertrend(IStrategy):
    INTERFACE_VERSION = 2
    minimal_roi = {
        "0": 100,
    }
    stoploss = -0.99
    
    use_custom_stoploss = True

    multiplier = 0.8
    period = 7
    
    trailing_stop = False
    timeframe = '1m'
    process_only_new_candles = False
    use_sell_signal = True
    sell_profit_only = True
    ignore_roi_if_buy_signal = False
    startup_candle_count: int = 50 * 5
    order_types = {
        'buy': 'limit',
        'sell': 'limit',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }
    order_time_in_force = {
        'buy': 'gtc',
        'sell': 'gtc'
    }    
    plot_config = {
        'main_plot': {
            'BOLLINGER': {},       
        },
        'subplots': {     
        }
    }
 
    def informative_pairs(self):
        return []; 

    def get_ticker_indicator(self):
        return int(self.timeframe[:-1])

    
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe = supertrend(dataframe, self.multiplier, self.period)
        dataframe['macd1m'], dataframe['macdsignal1m'], dataframe['macdhist1m'] = ta.MACD(dataframe['open'], fastperiod=11, slowperiod=25, signalperiod=9)
        dataframe['rsi1m'] = ta.RSI(dataframe['close'], timeperiod=14)
        def resampleDF(minutes):
            df = resample_to_interval(dataframe, self.get_ticker_indicator() * minutes)
            boll = qtpylib.bollinger_bands(qtpylib.typical_price(df), window=20, stds=2)
            df['bb_lower'] = boll['lower']
            df['bb_middle'] = boll['mid']
            df['bb_upper'] = boll['upper']
            df['rsi'] = ta.RSI(df['close'], timeperiod=14)  # Add RSI calculation here
            df['ema7'] = ta.EMA(df['close'], timeperiod=7)  # EMA calculation
            df['ema25'] = ta.EMA(df['close'], timeperiod=25)  # EMA calculation
            df['ema99'] = ta.EMA(df['close'], timeperiod=99)  # EMA calculation
            df['macd'], df['macdsignal'], df['macdhist'] = ta.MACD(df['close'], fastperiod=12, slowperiod=26, signalperiod=9)  # MACD calculation
            return df
        
        dataframe_5m = resampleDF(5)
        dataframe = resampled_merge(dataframe, dataframe_5m)    
        #dataframe.fillna(method='ffill', inplace=True)
        dataframe.bfill(inplace=True)

        return dataframe

    def populate_buy_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[(
            # (dataframe['macd1m'] < dataframe['macdhist1m']) &
            # (dataframe['macdsignal1m'] < dataframe['macdhist1m']) &
            # (qtpylib.crossed_above(dataframe['macd1m'], dataframe['macdsignal1m'])) &
            # (dataframe['rsi1m'] < 30) &
            (
            (dataframe['resample_{}_close'.format(self.get_ticker_indicator() * 5)] < dataframe['resample_{}_bb_lower'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_ema99'.format(self.get_ticker_indicator() * 5)] > dataframe['resample_{}_ema25'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_ema25'.format(self.get_ticker_indicator() * 5)] > dataframe['resample_{}_ema7'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_macd'.format(self.get_ticker_indicator() * 5)] < dataframe['resample_{}_macdsignal'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_macdsignal'.format(self.get_ticker_indicator() * 5)] < dataframe['resample_{}_macdhist'.format(self.get_ticker_indicator() * 5)])
         ) &
         (
             (dataframe['STX_' + str(self.period) + '_' + str(self.multiplier)] == 'down') &
             (dataframe['STX_' + str(self.period) + '_' + str(self.multiplier)].shift(1) == 'up') 
             )
            #(qtpylib.crossed_above(dataframe['resample_{}_macd'.format(self.get_ticker_indicator() * 5)],dataframe['resample_{}_macdsignal'.format(self.get_ticker_indicator() * 5)]))
        ),'buy'] = 1

        return dataframe

    def populate_sell_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[(
            (
            (dataframe['resample_{}_close'.format(self.get_ticker_indicator() * 5)] > dataframe['resample_{}_bb_upper'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_ema99'.format(self.get_ticker_indicator() * 5)] < dataframe['resample_{}_ema25'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_ema25'.format(self.get_ticker_indicator() * 5)] < dataframe['resample_{}_ema7'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_macd'.format(self.get_ticker_indicator() * 5)] > dataframe['resample_{}_macdsignal'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_macdsignal'.format(self.get_ticker_indicator() * 5)] > dataframe['resample_{}_macdhist'.format(self.get_ticker_indicator() * 5)])
         ) 
        # &
        #  (
        #      (dataframe['STX_' + str(self.period) + '_' + str(self.multiplier)] == 'down') &
        #      (dataframe['STX_' + str(self.period) + '_' + str(self.multiplier)].shift(1) == 'up') 
        #     )
        ),'sell'] = 1

        return dataframe