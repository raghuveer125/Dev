import numpy as np
import pandas as pd
from pandas import DataFrame
from freqtrade.strategy import IStrategy
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
import talib.abstract as ta
import logging
from datetime import datetime
from freqtrade.persistence import Trade
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.neural_network import MLPClassifier

logger = logging.getLogger(__name__)

class AI_Strategy1m_fraction_buy(IStrategy):
    INTERFACE_VERSION = 2

    minimal_roi = {
        "0": 0.1,
        "15": 0.01,
        "30": 0.02,
        "60": 0.03,
    }
    stoploss = -0.02
    timeframe = '1m'
    startup_candle_count: int = 50

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.model = RandomForestClassifier(n_estimators=100, random_state=42)
        self.logistic_model = LogisticRegression(random_state=42)
        self.svm_model = SVC(probability=True, random_state=42)
        self.knn_model = KNeighborsClassifier()
        self.gbm_model = GradientBoostingClassifier(random_state=42)
        self.mlp_model = MLPClassifier(random_state=42)
        self.scaler = StandardScaler()
        self.model_trained = False
        self.total_stake = 100
        self.trade_percentages = [0.1, 0.2, 0.3, 1.0]  # Percentages for each trade
        self.current_trade_amount_index = 0
        self.current_trade_id = None
        self.current_trade_amount = 0
        self.average_buy_price = 0
        self.buy_signals = []
        self.buy_amounts = []
        self.last_trade_candle = -6  # Initialize to a value that ensures trading is allowed initially

    def heikin_ashi(self, dataframe: DataFrame) -> DataFrame:
        heikin_ashi_df = dataframe.copy()
        heikin_ashi_df['close'] = (dataframe['open'] + dataframe['high'] + dataframe['low'] + dataframe['close']) / 4
        heikin_ashi_df['open'] = (dataframe['open'].shift(2) + dataframe['close'].shift(2)) / 2
        heikin_ashi_df['high'] = dataframe[['open', 'close', 'high']].max(axis=1)
        heikin_ashi_df['low'] = dataframe[['open', 'close', 'low']].min(axis=1)
        heikin_ashi_df.iloc[0, heikin_ashi_df.columns.get_loc('open')] = (dataframe.iloc[0]['open'] + dataframe.iloc[0]['close']) / 2
        return heikin_ashi_df

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        heikin_ashi_df = self.heikin_ashi(dataframe)
        dataframe['heikin_ashi_close'] = heikin_ashi_df['close']
        dataframe['heikin_ashi_open'] = heikin_ashi_df['open']
        dataframe['heikin_ashi_high'] = heikin_ashi_df['high']
        dataframe['heikin_ashi_low'] = heikin_ashi_df['low']
        
        dataframe['price_change'] = dataframe['close'].pct_change()
        dataframe['rolling_min'] = dataframe['close'].rolling(window=10).min()
        dataframe['rolling_max'] = dataframe['close'].rolling(window=10).max()
        dataframe['rolling_mean'] = dataframe['close'].rolling(window=10).mean()
        dataframe['rolling_std'] = dataframe['close'].rolling(window=10).std()
        dataframe['volume_change'] = dataframe['volume'].pct_change()

        # Add MACD indicator using Heikin Ashi close prices
        macd, macdsignal, macdhist = ta.MACD(heikin_ashi_df['close'], fastperiod=24, slowperiod=52, signalperiod=9)
        dataframe['macd'] = macd
        dataframe['macdsignal'] = macdsignal
        dataframe['macdhist'] = macdhist

        # Create heikin_ashi_green and heikin_ashi_red columns
        dataframe['heikin_ashi_green'] = dataframe['heikin_ashi_close'] > dataframe['heikin_ashi_open']
        dataframe['heikin_ashi_red'] = dataframe['heikin_ashi_close'] < dataframe['heikin_ashi_open']

        # Add EMA and SMA indicators
        for period in [3, 7, 9, 21, 50, 100, 200]:
            dataframe[f'ema_{period}'] = ta.EMA(dataframe['close'], timeperiod=period)
            dataframe[f'sma_{period}'] = ta.SMA(dataframe['close'], timeperiod=period)

        # Pull bid volume for buy and sell from the order book with error handling
        try:
            order_book = self.dp.orderbook(metadata['pair'], maximum=1)
            if order_book and 'bids' in order_book and 'asks' in order_book:
                dataframe['bid_buy_volume'] = order_book['bids'][0][1] if order_book['bids'] else 0
                dataframe['bid_sell_volume'] = order_book['asks'][0][1] if order_book['asks'] else 0
            else:
                dataframe['bid_buy_volume'] = 0
                dataframe['bid_sell_volume'] = 0
        except Exception as e:
            logger.error(f"Error fetching order book for {metadata['pair']}: {e}")
            dataframe['bid_buy_volume'] = 0
            dataframe['bid_sell_volume'] = 0

        # Add current buy and sell volume for the current candle
        dataframe['buy_volume'] = np.where(dataframe['close'] > dataframe['open'], dataframe['volume'], 0)
        dataframe['sell_volume'] = np.where(dataframe['close'] < dataframe['open'], dataframe['volume'], 0)

        return dataframe

    def train_model(self, dataframe: DataFrame) -> None:
        features = dataframe[['price_change', 'rolling_min', 'rolling_max', 'rolling_mean', 'rolling_std', 'volume_change']].dropna()
        target = (dataframe['close'].shift(-1) > dataframe['close']).astype(int).dropna()
        
        # Align features and target
        features = features.iloc[:-1]
        target = target.iloc[1:]

        min_length = min(len(features), len(target))
        features = features.iloc[:min_length]
        target = target.iloc[:min_length]

        # Ensure no infinite or NaN values
        features.replace([np.inf, -np.inf], np.nan, inplace=True)
        features.dropna(inplace=True)

        X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)
        self.scaler.fit(X_train)
        X_train_scaled = self.scaler.transform(X_train)
        self.model.fit(X_train_scaled, y_train)
        self.logistic_model.fit(X_train_scaled, y_train)
        self.svm_model.fit(X_train_scaled, y_train)
        self.knn_model.fit(X_train_scaled, y_train)
        self.gbm_model.fit(X_train_scaled, y_train)
        self.mlp_model.fit(X_train_scaled, y_train)
        self.model_trained = True
        # logger.info("Models trained successfully")

    def populate_buy_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Comment out previous buy signal logic
        # heikin_ashi_green = dataframe['heikin_ashi_close'] > dataframe['heikin_ashi_open']
        # heikin_ashi_red = dataframe['heikin_ashi_close'] < dataframe['heikin_ashi_open']
        # first_green_candle = heikin_ashi_green & (~heikin_ashi_green.shift(1).astype(bool))
        # second_green_candle = heikin_ashi_green & heikin_ashi_green.shift(1)
        
        # MACD condition
        # macd_condition = (dataframe['macd'] < dataframe['macdsignal']) & (dataframe['macd'] < dataframe['macdhist']) & (dataframe['macdsignal'] < dataframe['macdhist'])
        
        # EMA condition
        # ema_condition = (
        #     (dataframe['ema_3'] < dataframe['ema_7']) &
        #     (dataframe['ema_7'] < dataframe['ema_9']) &
        #     (dataframe['ema_9'] < dataframe['ema_21']) &
        #     (dataframe['ema_21'] < dataframe['ema_50']) &
        #     (dataframe['ema_50'] < dataframe['ema_100']) &
        #     (dataframe['ema_100'] < dataframe['ema_200'])
        # )

        # Check if there are at least 10 consecutive red candles
        # red_candle_count = heikin_ashi_red.rolling(window=10).sum()
        # green_candle_count = heikin_ashi_green.rolling(window=10).sum()
        # consecutive_red_condition = (red_candle_count >= 7) & (green_candle_count <= 3)

        # Ensure the consecutive red candle condition is met before checking other conditions
        # buy_condition = consecutive_red_condition.shift(1) & second_green_candle & first_green_candle.shift(1) & (~heikin_ashi_green.shift(2).astype(bool)) & macd_condition & ema_condition
        
        # dataframe['buy'] = 0
        # dataframe.loc[buy_condition, 'buy'] = 1

        # Buy on every 3rd candle
        dataframe['buy'] = 0
        dataframe.loc[dataframe.index % 3 == 0, 'buy'] = 1

        if dataframe['buy'].iloc[-1] == 1:
            current_candle = len(dataframe) - 1
            if current_candle - self.last_trade_candle >= 5:
                self.track_buy_signal(metadata['pair'], dataframe['close'].iloc[-1])
                self.last_trade_candle = current_candle

        return dataframe

    def track_buy_signal(self, pair: str, current_price: float) -> None:
        self.buy_signals.append(current_price)
        self.buy_amounts.append(self.total_stake * self.trade_percentages[self.current_trade_amount_index])

        if len(self.buy_signals) == 4:
            if (self.buy_signals[0] > self.buy_signals[1] > self.buy_signals[2] > self.buy_signals[3]):
                self.execute_buy(pair, current_price)
                self.buy_signals = []
                self.buy_amounts = []
            else:
                self.buy_signals = []
                self.buy_amounts = []

    def execute_buy(self, pair: str, current_price: float) -> None:
        current_candle = len(self.dp.get_analyzed_dataframe(pair, self.timeframe)[0]) - 1
        if self.current_trade_id is None or current_candle - self.last_trade_candle >= 3:
            amount = sum(self.buy_amounts)
            logger.info(f"Executing Buy - Amount: {amount}, Total Stake: {self.total_stake}")
            self.current_trade_id = self.create_trade(pair, amount, current_price)
            self.current_trade_amount = amount
            self.average_buy_price = current_price
            self.total_stake -= amount  # Ensure total stake is reduced by the amount used
            logger.info(f"After Buy - Current Trade Amount: {self.current_trade_amount}, Average Buy Price: {self.average_buy_price}, Remaining Stake: {self.total_stake}")
            self.last_trade_candle = current_candle
        else:
            logger.info(f"Ignoring Buy - Trade occurred within the last 3 candles")

    def populate_sell_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Generate sell signals on the second consecutive red Heikin Ashi candle after a green candle
        heikin_ashi_green = dataframe['heikin_ashi_close'] > dataframe['heikin_ashi_open']
        heikin_ashi_red = dataframe['heikin_ashi_close'] < dataframe['heikin_ashi_open']
        first_red_candle = heikin_ashi_red & (~heikin_ashi_red.shift(1).astype(bool))
        second_red_candle = heikin_ashi_red & heikin_ashi_red.shift(1)
        
        # MACD condition
        macd_condition = (dataframe['macd'] > dataframe['macdsignal']) & (dataframe['macd'] > dataframe['macdhist']) & (dataframe['macdsignal'] > dataframe['macdhist'])
        
        # EMA condition
        ema_condition = (
            (dataframe['ema_3'] > dataframe['ema_7']) &
            (dataframe['ema_7'] > dataframe['ema_9']) &
            (dataframe['ema_9'] > dataframe['ema_21']) &
            (dataframe['ema_21'] > dataframe['ema_50']) &
            (dataframe['ema_50'] > dataframe['ema_100']) &
            (dataframe['ema_100'] > dataframe['ema_200'])
        )

        # Check if there are at least 10 consecutive green candles
        green_candle_count = heikin_ashi_green.rolling(window=10).sum()
        red_candle_count = heikin_ashi_red.rolling(window=10).sum()
        consecutive_green_condition = (green_candle_count >= 7) & (red_candle_count <= 3)

        # Ensure the consecutive green candle condition is met before checking other conditions
        sell_condition = consecutive_green_condition.shift(1) & second_red_candle & first_red_candle.shift(1) & (~heikin_ashi_red.shift(2).astype(bool)) & macd_condition & ema_condition
        dataframe['sell'] = 0
        dataframe.loc[sell_condition, 'sell'] = 1

        if dataframe['sell'].iloc[-1] == 1 and self.current_trade_id is not None:
            self.execute_sell(metadata['pair'], dataframe['close'].iloc[-1])

        return dataframe

    def execute_sell(self, pair: str, current_price: float) -> None:
        self.close_trade(self.current_trade_id, current_price)
        self.current_trade_id = None
        self.current_trade_amount_index = 0
        self.current_trade_amount = 0
        self.average_buy_price = 0

    def create_trade(self, pair: str, amount: float, price: float) -> str:
        # Implement trade creation logic here
        # Ensure the amount does not exceed the total stake
        if amount > self.total_stake:
            amount = self.total_stake
        self.total_stake -= amount
        try:
            # Attempt to create the trade
            trade_id = self.dp.create_trade(pair, amount, price)
            return trade_id
        except Exception as e:
            logger.error(f"Unable to create trade for {pair}: {e}")
            self.total_stake += amount  # Revert the stake reduction if trade creation fails
            return None

    def update_trade(self, trade_id: str, amount: float, average_price: float) -> None:
        # Implement trade update logic here
        pass

    def close_trade(self, trade_id: str, price: float) -> None:
        # Implement trade closing logic here
        # Reset the total stake when the trade is closed
        self.total_stake = 100
        pass

    def custom_stoploss(self, pair: str, trade: 'Trade', current_time: datetime, current_rate: float, current_profit: float, **kwargs) -> float:
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        atr = dataframe['rolling_std'].iloc[-1]  # Using rolling standard deviation as a proxy for volatility
        initial_stop_loss = trade.open_rate * (1 + self.stoploss)

        # Adjust stop loss dynamically based on current profit
        if current_profit > 0:
            trailing_stop_loss = current_rate * (1 + self.stoploss)
            stop_loss = max(initial_stop_loss, trailing_stop_loss)
        else:
            stop_loss = initial_stop_loss

        return stop_loss