import numpy as np  # noqa
import pandas as pd  # noqa
from pandas import DataFrame

from freqtrade.strategy import IStrategy
from datetime import datetime

import talib.abstract as ta 
import freqtrade.vendor.qtpylib.indicators as qtpylib
from technical.util import resample_to_interval, resampled_merge
from telegram import Bot
from freqtrade.persistence import Trade

class Himanshu_WinR(IStrategy):
    INTERFACE_VERSION = 2
    minimal_roi = {
        "0": 0.1,
        "15": 0.01,
        "30": 0.02,
        "60": 0.03,
    }
    stoploss = -0.10
    
    use_custom_stoploss = False

    def custom_stoploss(self, pair: str, trade: 'Trade', current_time: 'datetime', current_rate: float,
                        current_profit: float, **kwargs) -> float:
        # Check if the current profit is greater than $10
        if current_profit * trade.stake_amount > 5:
            # Move the stoploss to breakeven
            return 0

        # Use the initial stoploss otherwise
        return -0.05  # replace with your initial stoploss
    
    trailing_stop = False
    timeframe = '1m'
    process_only_new_candles = False
    use_sell_signal = True
    sell_profit_only = True
    ignore_roi_if_buy_signal = False
    startup_candle_count: int = 30 * 5
    order_types = {
        'buy': 'limit',
        'sell': 'limit',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }
    order_time_in_force = {
        'buy': 'gtc',
        'sell': 'gtc'
    }    
    plot_config = {
        'main_plot': {
            'BOLLINGER': {},       
        },
        'subplots': {     
        }
    }

    def custom_buy(self, pair: str, current_price: float, stake_amount: float) -> bool:
    # Define the specific condition for SOL/USDT
        if pair == 'SOL/USDT' and current_price <= 143:
            self.execute_buy(pair, stake_amount)
            return True
        # Additional condition for SHIB/USDT
        elif pair == 'SHIB/USDT' and current_price <= 0.000022048:
            # Assuming $400 is the stake amount for SHIB/USDT
            shib_stake_amount = 400
            self.execute_buy(pair, shib_stake_amount)
            return True
        # Additional condition for XRP/USDT
        elif pair == 'XRP/USDT' and current_price < 0.4778:
            # Assuming $400 is the stake amount for XRP/USDT
            xrp_stake_amount = 400
            self.execute_buy(pair, xrp_stake_amount)
            return True
        return False

    def execute_buy(self, pair: str, stake_amount: float):
    # Example using a hypothetical exchange API client
    
        try:
            order = self.exchange.create_order(symbol=pair, type="limit", side="buy", amount=stake_amount, price=None)
            print(f"Order placed: {order}")
        except Exception as e:
            print(f"Error executing buy: {e}")

    def custom_sell(self, pair: str, trade: 'Trade', current_time: 'datetime', current_rate: float,
                current_profit: float, **kwargs) -> bool:
        
        if current_profit > 0.0025:
            return True  # Sell the trade

        # Define profit and loss thresholds based on stake_amount ranges
        profit_loss_thresholds = {
            (50, 2000): {"profit": 100, "loss": -99}
            # (150, 250): {"profit": 3, "loss": -3},
            # (250, 500): {"profit": 4.5, "loss": -5},
            # (500, 650): {"profit": 8, "loss": -6},
            # (650, 1000): {"profit": 18, "loss": -17},
        }

        # Find the correct threshold range for the current stake_amount
        thresholds = None
        for stake_range, values in profit_loss_thresholds.items():
            if stake_range[0] <= trade.stake_amount <= stake_range[1]:
                thresholds = values
                break

        # If thresholds are found for the current stake_amount range
        if thresholds:
            # Check if the current profit meets the profit or loss criteria
            if current_profit * trade.stake_amount >= thresholds["profit"] or \
            current_profit * trade.stake_amount <= thresholds["loss"]:
                return True

        return False
    
    def informative_pairs(self):
        return []; 

    def get_ticker_indicator(self):
        return int(self.timeframe[:-1])
    
    def custom_junk_ma(self, series: pd.Series, length: int, phase: int, power: int) -> pd.Series:
        # Custom calculation for the "junk" moving average
        # This is a placeholder for the actual calculation logic
        # Replace this with the actual formula for your "junk" moving average
        return series.rolling(window=length).mean() ** power

    
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['macd1m'], dataframe['macdsignal1m'], dataframe['macdhist1m'] = ta.MACD(dataframe['open'], fastperiod=24, slowperiod=52, signalperiod=9)
        dataframe['rsi1m'] = ta.RSI(dataframe['close'], timeperiod=14)
        dataframe.bfill(inplace=True)

        dataframe['willr'] = ta.WILLR(dataframe['high'], dataframe['low'], dataframe['close'], timeperiod=140)
        #SMA Smooth 9 & 20
        dataframe['sma20'] = ta.SMA(dataframe['close'], timeperiod=20)
        dataframe['sma20_smooth9'] = ta.SMA(dataframe['sma20'], timeperiod=9)

        #EMA Smooth 9 & 20
        dataframe['ema20'] = ta.EMA(dataframe['close'], timeperiod=20)
        dataframe['ema20_smooth9'] = ta.EMA(dataframe['ema20'], timeperiod=9)

        #Junk 
        dataframe['junk_ma20'] = ta.SMA(dataframe['close'], timeperiod=20)

        #ADX
        dataframe['adx'] = ta.ADX(dataframe['high'], dataframe['low'], dataframe['close'], timeperiod=14)






        return dataframe
    
    def populate_buy_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        print("Populating buy trend")
        print(dataframe[['willr', 'rsi1m', 'macd1m', 'macdsignal1m', 'macdhist1m', 'sma20_smooth9', 'ema20_smooth9', 'junk_ma20', 'adx']].tail())

        dataframe.loc[(
            (dataframe['willr'] < -95) &  # Williams %R < -95
            (dataframe['rsi1m'] < 30) &  # RSI < 30
            (dataframe['macd1m'] < dataframe['macdhist1m']) &  # MACD1m < MACDHist1m
            (dataframe['macdsignal1m'] < dataframe['macdhist1m']) &  # MACDSignal1m < MACDHist1m
            (qtpylib.crossed_above(dataframe['macd1m'], dataframe['macdsignal1m'])) &  # MACD1m crossover MACDSignal1m
            (dataframe['adx'] > 25)  # ADX > 25
        ), 'buy'] = 1
        return dataframe
    
    def populate_sell_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[(
            (dataframe['willr'] > -5) &  # Williams %R < -95
            (dataframe['macd1m'] > dataframe['macdhist1m']) &  # MACD1m < MACDHist1m
            (dataframe['macdsignal1m'] > dataframe['macdhist1m']) 
            # &  # MACDSignal1m < MACDHist1m
            # (qtpylib.crossed_above(dataframe['macdsignal1m'], dataframe['macdl1m']))  # MACD1m crossover MACDSignal1m
        ), 'sell'] = 1
        return dataframe