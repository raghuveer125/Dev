import numpy as np  # noqa
import pandas as pd  # noqa
from pandas import DataFrame

from freqtrade.strategy import IStrategy

import talib.abstract as ta 
import freqtrade.vendor.qtpylib.indicators as qtpylib
from technical.util import resample_to_interval, resampled_merge
from freqtrade.strategy import IStrategy, merge_informative_pair

class BD_MACD1m5m15m30m1h(IStrategy):
    INTERFACE_VERSION = 2
    minimal_roi = {
        "0": 0.01
    }
    stoploss = -0.02
    
    use_custom_stoploss = True
    
    trailing_stop = True
    timeframe = '1m'
    process_only_new_candles = False
    use_sell_signal = True
    sell_profit_only = True
    ignore_roi_if_buy_signal = True
    startup_candle_count: int = 4500
    order_types = {
        'buy': 'limit',
        'sell': 'limit',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }
    order_time_in_force = {
        'buy': 'gtc',
        'sell': 'gtc'
    }    
    plot_config = {
        'main_plot': {
            'BOLLINGER': {},
            'ema7': {},
            'ema25': {},
            'ema99': {},
        },
        'subplots': {
            
            
        }
    }

    # def get_strategy_name_dict(self):
    #     return {
    #         'strategy_name': self.__class__.__name__,
    #         'plot_config': self.plot_config,
    #         'plot_dataframe_columns': ['date', 'open', 'high', 'low', 'close', 'volume', 'ema7', 'ema25', 'ema99']
    #     }
 

    def get_ticker_indicator(self):
        return int(self.timeframe[:-1])

    def informative_pairs(self):
        pairs = self.dp.current_whitelist()
        informative_pairs = [(pair, timeframe) for pair in pairs for timeframe in ["5m","15m","30m","1h"]]
        return informative_pairs

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        if not self.dp:
            return dataframe

        # Get the current pair
        pair = metadata['pair']

        dataframe['macd'], dataframe['macdsignal'], dataframe['macdhist'] = ta.MACD(dataframe['close'], fastperiod=12, slowperiod=26, signalperiod=9)

        # Fetch the data for each informative pair
        for timeframe in ["5m","15m","30m","1h"]:
            informative = self.dp.get_pair_dataframe(pair=pair, timeframe=timeframe)

            # Calculate EMAs
            informative[f'ema7_{timeframe}'] = ta.EMA(informative['close'], timeperiod=7)
            informative[f'ema25_{timeframe}'] = ta.EMA(informative['close'], timeperiod=25)
            informative[f'ema99_{timeframe}'] = ta.EMA(informative['close'], timeperiod=99)

            # Calculate MACD
            informative[f'macd_{timeframe}'], informative[f'macdsignal_{timeframe}'], informative[f'macdhist_{timeframe}'] = ta.MACD(informative['close'], fastperiod=12, slowperiod=26, signalperiod=9)

            # Merge the informative pair dataframe into the original dataframe
            dataframe = merge_informative_pair(dataframe, informative, self.timeframe, timeframe, ffill=True)

        return dataframe

    def populate_buy_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        pair = metadata['pair']

        dataframe.loc[
            (
                
                (dataframe[f'{pair}_macdsignal_15m_15m'] < dataframe[f'{pair}_macdhist_15m_15m']) &
                (dataframe[f'{pair}_macd_15m_15m'] < dataframe[f'{pair}_macdsignal_15m_15m']) &

                (dataframe[f'{pair}_macdsignal_30m_30m'] < dataframe[f'{pair}_macdhist_30m_30m']) &
                (dataframe[f'{pair}_macd_30m_30m'] < dataframe[f'{pair}_macdsignal_30m_30m']) &

                (dataframe[f'{pair}_macdsignal_1h_1h'] < dataframe[f'{pair}_macdhist_1h_1h']) &
                (dataframe[f'{pair}_macd_1h_1h'] < dataframe[f'{pair}_macdsignal_1h_1h']) &

                (dataframe[f'{pair}_macd_5m_5m'] < dataframe[f'{pair}_macdhist_5m_5m']) &
                (dataframe[f'{pair}_macdsignal_5m_5m'] < dataframe[f'{pair}_macdhist_5m_5m']) &

                
                (dataframe['macd'] < dataframe['macdhist']) &
                (dataframe['macdsignal'] < dataframe['macdhist']) &
                (qtpylib.crossed_above(dataframe['macd'], dataframe['macdsignal']))
            ),
            'buy'] = 1

        return dataframe

    def populate_sell_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        pair = metadata['pair']
        dataframe.loc[
            (
                (dataframe[f'{pair}_macdsignal_15m_15m'] > dataframe[f'{pair}_macdhist_15m_15m']) &
                (dataframe[f'{pair}_macd_15m_15m'] > dataframe[f'{pair}_macdsignal_15m_15m']) &

                (dataframe[f'{pair}_macdsignal_30m_30m'] > dataframe[f'{pair}_macdhist_30m_30m']) &
                (dataframe[f'{pair}_macd_30m_30m'] > dataframe[f'{pair}_macdsignal_30m_30m']) &

                (dataframe[f'{pair}_macdsignal_1h_1h'] > dataframe[f'{pair}_macdhist_1h_1h']) &
                (dataframe[f'{pair}_macd_1h_1h'] > dataframe[f'{pair}_macdsignal_1h_1h']) &

                (dataframe[f'{pair}_macd_5m_5m'] > dataframe[f'{pair}_macdhist_5m_5m']) &
                (dataframe[f'{pair}_macdsignal_5m_5m'] > dataframe[f'{pair}_macdhist_5m_5m']) &

                (dataframe['macd'] > dataframe['macdhist']) &
                (dataframe['macdsignal'] > dataframe['macdhist']) &
                (qtpylib.crossed_below(dataframe['macd'], dataframe['macdsignal']))
            ),
            'sell'] = 1

        return dataframe