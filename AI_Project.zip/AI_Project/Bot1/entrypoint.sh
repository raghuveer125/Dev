#!/bin/bash

# Create necessary directories
mkdir -p /freqtrade/user_data /freqtrade/user_data/Bot1 /freqtrade/user_data/logs

# Debug statements to check directory structure
echo 'Contents of /freqtrade:'
ls -l /freqtrade
echo 'Contents of /freqtrade/user_data:'
ls -l /freqtrade/user_data
echo 'Contents of /freqtrade/user_data/Bot1:'
ls -l /freqtrade/user_data/Bot1

# Activate virtual environment and run freqtrade
source /opt/venv/bin/activate
freqtrade trade --logfile /freqtrade/user_data/logs/freqtrade.log --db-url sqlite:////freqtrade/user_data/tradesv1.sqlite --config /freqtrade/user_data/Bot1/config1.json --strategy AI_Strategy