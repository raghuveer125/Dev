import numpy as np  # noqa
import pandas as pd  # noqa
from pandas import DataFrame

from freqtrade.strategy import IStrategy

import talib.abstract as ta 
import freqtrade.vendor.qtpylib.indicators as qtpylib
from technical.util import resample_to_interval, resampled_merge

class Boll5_noSell(IStrategy):
    INTERFACE_VERSION = 2
    minimal_roi = {
        "0": 1
    }
    stoploss = -0.10
    
    use_custom_stoploss = True
    
    trailing_stop = True
    timeframe = '3m'
    process_only_new_candles = False
    use_sell_signal = True
    sell_profit_only = True
    ignore_roi_if_buy_signal = False
    startup_candle_count: int = 30 * 5
    order_types = {
        'buy': 'limit',
        'sell': 'limit',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }
    order_time_in_force = {
        'buy': 'gtc',
        'sell': 'gtc'
    }    
    plot_config = {
        'main_plot': {
            'BOLLINGER': {},
            'ema7': {},
            'ema25': {},
            'ema99': {},
        },
        'subplots': {
            
            
        }
    }

    def get_strategy_name_dict(self):
        return {
            'strategy_name': self.__class__.__name__,
            'plot_config': self.plot_config,
            'plot_dataframe_columns': ['date', 'open', 'high', 'low', 'close', 'volume', 'ema7', 'ema25', 'ema99']
        }
 
    def informative_pairs(self):
        return []; 

    def get_ticker_indicator(self):
        return int(self.timeframe[:-1])

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        
        def resampleDF(minutes):
            df = resample_to_interval(dataframe, self.get_ticker_indicator() * minutes)
            boll = qtpylib.bollinger_bands(qtpylib.typical_price(df), window=20, stds=2)
            df['bb_lower'] = boll['lower']
            df['bb_middle'] = boll['mid']
            df['bb_upper'] = boll['upper']
            df['rsi'] = ta.RSI(df['close'], timeperiod=14)  # Add RSI calculation here
            df['ema7'] = ta.EMA(df['close'], timeperiod=7)  # EMA calculation
            df['ema25'] = ta.EMA(df['close'], timeperiod=24)  # EMA calculation
            df['ema99'] = ta.EMA(df['close'], timeperiod=98)  # EMA calculation
            df['macd'], df['macdsignal'], df['macdhist'] = ta.MACD(df['close'], fastperiod=12, slowperiod=26, signalperiod=9)  # MACD calculation
            return df

        dataframe_5m = resampleDF(5)
        dataframe_15m = resampleDF(15)  # New 15-minute dataframe
        dataframe_30m = resampleDF(30)

        dataframe = resampled_merge(dataframe, dataframe_5m)
        dataframe = resampled_merge(dataframe, dataframe_15m)  # Merge 15-minute dataframe
        dataframe = resampled_merge(dataframe, dataframe_30m) 

        #dataframe.fillna(method='ffill', inplace=True)
        dataframe.bfill(inplace=True)

        return dataframe

    def populate_buy_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[(
            (dataframe['resample_{}_close'.format(self.get_ticker_indicator() * 5)] < dataframe['resample_{}_bb_lower'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_ema99'.format(self.get_ticker_indicator() * 5)] > dataframe['resample_{}_ema25'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_ema25'.format(self.get_ticker_indicator() * 5)] > dataframe['resample_{}_ema7'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_macd'.format(self.get_ticker_indicator() * 5)] < dataframe['resample_{}_macdsignal'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_macdsignal'.format(self.get_ticker_indicator() * 5)] < dataframe['resample_{}_macdhist'.format(self.get_ticker_indicator() * 5)])
        ),'buy'] = 1

        return dataframe

    def populate_sell_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[(
            (dataframe['resample_{}_close'.format(self.get_ticker_indicator() * 5)] > dataframe['resample_{}_bb_lower'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_ema99'.format(self.get_ticker_indicator() * 5)] < dataframe['resample_{}_ema25'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_ema25'.format(self.get_ticker_indicator() * 5)] < dataframe['resample_{}_ema7'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_macd'.format(self.get_ticker_indicator() * 5)] > dataframe['resample_{}_macdsignal'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_macdsignal'.format(self.get_ticker_indicator() * 5)] > dataframe['resample_{}_macdhist'.format(self.get_ticker_indicator() * 5)])
        ),'sell'] = 1

        return dataframe