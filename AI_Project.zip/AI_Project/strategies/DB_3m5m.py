import numpy as np  # noqa
import pandas as pd  # noqa
from pandas import DataFrame

from freqtrade.strategy import IStrategy

import talib.abstract as ta 
import freqtrade.vendor.qtpylib.indicators as qtpylib
from technical.util import resample_to_interval, resampled_merge
from telegram import Bot

class DB_3m5m(IStrategy):
    INTERFACE_VERSION = 2
    minimal_roi = {
        "0": 1,
        "15": 0.01,
    }
    stoploss = -0.99
    
    use_custom_stoploss = False

    def custom_stoploss(self, pair: str, trade: 'Trade', current_time: 'datetime', current_rate: float,
                        current_profit: float, **kwargs) -> float:
        # Check if the current profit is greater than $10
        if current_profit * trade.stake_amount > 0.01:
            # Move the stoploss to breakeven
            return 0

        # Use the initial stoploss otherwise
        return -0.10  # replace with your initial stoploss
    
    trailing_stop = False
    timeframe = '3m'
    process_only_new_candles = False
    use_sell_signal = True
    sell_profit_only = True
    ignore_roi_if_buy_signal = False
    startup_candle_count: int = 30 * 5
    order_types = {
        'buy': 'limit',
        'sell': 'limit',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }
    order_time_in_force = {
        'buy': 'gtc',
        'sell': 'gtc'
    }    
    plot_config = {
        'main_plot': {
            'BOLLINGER': {},
            
        },
        'subplots': {
            
            
        }
    }

    def custom_sell(self, pair: str, trade: 'Trade', current_time: 'datetime', current_rate: float,
                current_profit: float, **kwargs) -> bool:
        if current_profit > 0.03:
            return True  # Sell the trade
        # Define profit and loss thresholds based on stake_amount ranges
        profit_loss_thresholds = {
            (50, 2000): {"profit": 200, "loss": -99}
        #    (150, 250): {"profit": 3, "loss": -3},
        #    (250, 500): {"profit": 4.5, "loss": -5},
        #    (500, 650): {"profit": 8, "loss": -6},
        #    (650, 1000): {"profit": 18, "loss": -17},
        }

        # Find the correct threshold range for the current stake_amount
        thresholds = None
        for stake_range, values in profit_loss_thresholds.items():
            if stake_range[0] <= trade.stake_amount <= stake_range[1]:
                thresholds = values
                break

        # If thresholds are found for the current stake_amount range
        if thresholds:
            # Check if the current profit meets the profit or loss criteria
            if current_profit * trade.stake_amount >= thresholds["profit"] or \
            current_profit * trade.stake_amount <= thresholds["loss"]:
                return True

        return False
    
    def informative_pairs(self):
        return []; 

    def get_ticker_indicator(self):
        return int(self.timeframe[:-1])

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        
        dataframe['macd3m'], dataframe['macdsignal3m'], dataframe['macdhist3m'] = ta.MACD(dataframe['open'], fastperiod=10, slowperiod=24, signalperiod=7)
        def resampleDF(minutes):
            df = resample_to_interval(dataframe, self.get_ticker_indicator() * minutes)
            boll = qtpylib.bollinger_bands(qtpylib.typical_price(df), window=20, stds=2)
            df['bb_lower'] = boll['lower']
            df['bb_middle'] = boll['mid']
            df['bb_upper'] = boll['upper']
            df['rsi'] = ta.RSI(df['close'], timeperiod=14)  # Add RSI calculation here
            df['ema7'] = ta.EMA(df['close'], timeperiod=7)  # EMA calculation
            df['ema25'] = ta.EMA(df['close'], timeperiod=25)  # EMA calculation
            df['ema99'] = ta.EMA(df['close'], timeperiod=99)  # EMA calculation
            df['macd'], df['macdsignal'], df['macdhist'] = ta.MACD(df['close'], fastperiod=12, slowperiod=26, signalperiod=9)  # MACD calculation
            return df

        dataframe_5m = resampleDF(5)
        dataframe = resampled_merge(dataframe, dataframe_5m)    
        #dataframe.fillna(method='ffill', inplace=True)
        dataframe.bfill(inplace=True)
        
        return dataframe

    def populate_buy_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        bot = Bot(token='7042655101:AAG6NO7v0oBpvYJeNdrVFMNYxbqW50grmoY')
        dataframe.loc[(
            (dataframe['macd3m'] < dataframe['macdhist3m']) &
            (dataframe['macdsignal3m'] < dataframe['macdhist3m']) &
            (qtpylib.crossed_above(dataframe['macd3m'], dataframe['macdsignal3m'])) &
            (dataframe['resample_{}_close'.format(self.get_ticker_indicator() * 5)] < dataframe['resample_{}_bb_lower'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_ema99'.format(self.get_ticker_indicator() * 5)] > dataframe['resample_{}_ema25'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_ema25'.format(self.get_ticker_indicator() * 5)] > dataframe['resample_{}_ema7'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_macd'.format(self.get_ticker_indicator() * 5)] < dataframe['resample_{}_macdsignal'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_macdsignal'.format(self.get_ticker_indicator() * 5)] < dataframe['resample_{}_macdhist'.format(self.get_ticker_indicator() * 5)])
        ),'buy'] = 1
        for _, row in dataframe.iterrows():
                    if row['buy'] == 1:
                        bot.send_message(chat_id='2011156012', text=f"Entry signal for {metadata['pair']} at price {row['close']}")
        return dataframe

    def populate_sell_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[(
            (dataframe['resample_{}_close'.format(self.get_ticker_indicator() * 5)] > dataframe['resample_{}_bb_upper'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_ema99'.format(self.get_ticker_indicator() * 5)] < dataframe['resample_{}_ema25'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_ema25'.format(self.get_ticker_indicator() * 5)] < dataframe['resample_{}_ema7'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_macd'.format(self.get_ticker_indicator() * 5)] > dataframe['resample_{}_macdsignal'.format(self.get_ticker_indicator() * 5)]) &
            (dataframe['resample_{}_macdsignal'.format(self.get_ticker_indicator() * 5)] > dataframe['resample_{}_macdhist'.format(self.get_ticker_indicator() * 5)])
        ),'sell'] = 1

        return dataframe